from flaskblog import app, db, bcrypt
from flaskblog.models import User,Register_item,Report_item,RetrievalRequest
from datetime import datetime
import secrets


with app.app_context():
    db.create_all()


admin_email = "FinditAdmin@gmail.com"
admin_password = "Admin123" 
admin_name = "N/A"
admin_contact_no = "N/A"
admin_course = "N/A"
admin_account_no = "N/A"


with app.app_context():
    admin_user = User.query.filter_by(email=admin_email).first()
    if not admin_user:
        hashed_password = bcrypt.generate_password_hash(admin_password).decode('utf-8')
        account_number = admin_contact_no
        admin_user = User(Account_Id=account_number, student_no=admin_email, Fullname=admin_name, Contact=admin_contact_no, Course=admin_course,
                          email=admin_email, password=hashed_password, Date_of_Register=datetime.utcnow(), Otp=secrets.token_hex(3))
        db.session.add(admin_user)
        db.session.commit()