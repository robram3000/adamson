from flaskblog import db, login_manager
from flask_login import UserMixin
from datetime import datetime
import secrets


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    Account_Id = db.Column(db.String(100), nullable=False)
    student_no = db.Column(db.String(20), unique=True, nullable=False)
    Fullname = db.Column(db.String(100), nullable=False)
    Contact = db.Column(db.String(100), nullable=False)
    Course = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    image_file = db.Column(db.String(20), nullable=False, default='default.jpg')
    password = db.Column(db.String(60), nullable=False)
    Date_of_Register = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    Otp = db.Column(db.String(6), nullable=False, default=lambda: secrets.token_hex(3))
    
    def __repr__(self):
        return f"User('{self.student_no}', '{self.email}', '{self.image_file}')"

class Register_item(db.Model):
    Item_Id = db.Column(db.Integer, primary_key=True)
    accno = db.Column(db.String(100),nullable = True)
    Serial_No = db.Column(db.String(100), nullable=False)
    Student_No = db.Column(db.String(100), nullable=False)
    Fullname = db.Column(db.String(100), nullable=False)
    Contact = db.Column(db.String(100), nullable=False)
    Course = db.Column(db.String(100), nullable=False)
    Date_Lost = db.Column(db.Date, nullable=True)
    Location_Lost = db.Column(db.String(100), nullable=True)
    Category = db.Column(db.String(50), nullable=False)
    Item_Name = db.Column(db.Text, nullable=False)
    Type_Item = db.Column(db.Text, nullable=False)
    Color = db.Column(db.Text, nullable=False)
    Date_of_Register = db.Column(db.DateTime, default=datetime.utcnow)
    Date_of_Claim = db.Column(db.DateTime , nullable = True)
    Status = db.Column(db.Text, nullable=False)
    Image = db.Column(db.String(1000), nullable=True)
    description = db.Column(db.Text, nullable=False)

    def __repr__(self):
        return f"Register('{self.Item_Id}','{self.Serial_No}','{self.Image}')"

class Report_item(db.Model):
    Item_Id = db.Column(db.Integer, primary_key=True)
    Serial_No = db.Column(db.String(100), nullable=False)
    Student_No = db.Column(db.String(100), nullable=False)
    Fullname = db.Column(db.String(100), nullable=False)
    Contact = db.Column(db.String(100), nullable=False)
    Course = db.Column(db.String(100), nullable=False)
    Date_Lost = db.Column(db.Date, nullable=False)
    Location_Lost = db.Column(db.String(100), nullable=False)
    Item_Name = db.Column(db.String(100), nullable=False)
    Type_of_item = db.Column(db.String(50), nullable=False)
    Color = db.Column(db.String(50), nullable=False)
    Category = db.Column(db.String(50), nullable=False)
    Status = db.Column(db.String(20), nullable=False, default='Lost')
    Description = db.Column(db.String(300), nullable=False)
    Report_Date = db.Column(db.DateTime, default=datetime.utcnow)
    img_item = db.Column(db.String(1000), nullable=False)
    
    def __repr__(self):
        return f"Report_item('{self.Item_Id}', '{self.Serial_No}')"
    
class RetrievalRequest(db.Model):
    request_id = db.Column(db.Integer, primary_key=True)
    item_id = db.Column(db.Integer, nullable=False)
    item_SN = db.Column(db.String(100), nullable=False)
    Request_SN = db.Column(db.String(100), nullable=False)
    student_no = db.Column(db.String(100), nullable=False)
    fullname = db.Column(db.String(100), nullable=False)
    course = db.Column(db.String(100), nullable=False)
    contact = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    id_img = db.Column(db.String(1000), nullable=False)  
    sign_img = db.Column(db.String(1000), nullable=False)
    status = db.Column(db.String(255), nullable=False)