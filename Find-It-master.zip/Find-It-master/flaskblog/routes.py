import os
import secrets
from PIL import Image
from flask import render_template, url_for, flash, redirect, request , current_app,abort,session
from flaskblog import app, db, bcrypt
from flaskblog.forms import RegistrationForm, LoginForm, UpdateAccountForm , RegisterItemFormss ,ReportItemForm,RegisterItemFormUser
from flaskblog.models import User ,Register_item,Report_item,RetrievalRequest
from flask_login import login_user, current_user, logout_user, login_required
from werkzeug.utils import secure_filename
from functools import wraps
from sqlalchemy import or_
from sqlalchemy.exc import SQLAlchemyError
import datetime ,random ,string , base64 , logging , time,uuid


# HOME PAGE
@app.route("/")
@app.route("/home", methods=['GET', 'POST'])
def home():
    posts = Register_item.query 

    if request.method == 'POST':
        start_date = request.form.get('start-date')
        end_date = request.form.get('end-date')
        item_type = request.form.get('item-type')
        search_query = request.form.get('search-item')

        if item_type:
            posts = posts.filter_by(Type_Item=item_type)
        if start_date:
            posts = posts.filter(Register_item.Date_Lost >= start_date)
        if end_date:
            posts = posts.filter(Register_item.Date_Lost <= end_date)
        if search_query:
            search_pattern = f"%{search_query}%"
            posts = posts.filter(or_(
                Register_item.Item_Name.ilike(search_pattern),
                Register_item.Color.ilike(search_pattern),
                Register_item.Type_Item.ilike(search_pattern),
                Register_item.Location_Lost.ilike(search_pattern),
                Register_item.Category.ilike(search_pattern)
            ))

    posts = posts.all()
    image_folder_path = os.path.join(app.root_path, 'static', 'Images')   

    return render_template('home.html', posts=posts,image_folder_path=image_folder_path)

@app.route("/about")
def about():
    return render_template('ABOUT-US-USER.html', title='About')
@app.route('/TermAndConditions')
def termandconditions():
    return render_template("TERM-AND-CONDITION.html")
@app.route('/Privacypolicy')
def privacypolicy():
    return render_template("PRIVACY-AND-POLICY.html")
@app.route('/FAQ')
def FAQ():
    return render_template("FAQS.html")




@app.route("/register", methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        account_number = generate_account_number()
        user = User(Account_Id=account_number, student_no=form.student_no.data, email=form.email.data, password=hashed_password, Fullname=form.fullname.data, Contact=form.contact.data, Course=form.course.data)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login', msg_suc = 'Your account has been created! You are now able to log in')) 
    return render_template('register.html', title='Register', form=form)

def generate_account_number():
    prefix = "ACC"  
    date_part = datetime.datetime.now().strftime("%Y%m%d%H%M%S") 
    random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))  
    return f"{prefix}-{date_part}-{random_part}"



@app.route("/login", methods=['GET', 'POST'])
def login():
    form = LoginForm()
    msg_suc = request.args.get('msg_suc') 
    msg_not = None  
    if form.validate_on_submit():
        studentno = User.query.filter_by(student_no=form.studentno.data).first()
        if form.studentno.data == "FinditAdmin@gmail.com" and form.password.data == "Admin123":
            admin_user = User.query.filter_by(email="FinditAdmin@gmail.com").first()
            if admin_user:
                login_user(admin_user)
                return redirect(url_for('dashboard'))
        
        if studentno and bcrypt.check_password_hash(studentno.password, form.password.data):
            login_user(studentno, remember=form.remember.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('home'))
        else:
            msg_not = 'Login Unsuccessful. Please check Student No and password.'
    
    return render_template('Log_in.html', title='Login', form=form, msg_suc=msg_suc, msg_not=msg_not)



@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('home'))






# FOR USER FUNCTION IF THE USER WAS LOG IN 

def save_picture(form_picture):
    random_hex = secrets.token_hex(8)
    f_name, f_ext = os.path.splitext(form_picture.filename)
    picture_fn = random_hex + f_ext
    picture_path = os.path.join(app.root_path, 'static/profile_pics', picture_fn)
    output_size = (125,125)
    i = Image.open(form_picture)
    i.thumbnail(output_size)
    i.save(picture_path)

    return picture_fn

@app.route("/account", methods=['GET', 'POST'])
@login_required
def account():
    form = UpdateAccountForm()
    if form.validate_on_submit():
        if form.picture.data:
            picture_file = save_picture(form.picture.data)
            current_user.image_file = picture_file
        current_user.student_no = form.studentno.data
        current_user.email = form.email.data
        db.session.commit()
        flash('Your account has been updated', 'success')
        return redirect(url_for('account'))
    elif request.method == 'GET':
        form.studentno.data = current_user.student_no
        form.email.data = current_user.email
    image_file = url_for('static', filename='profile_pics/' + current_user.image_file)
    return render_template('account.html', title='Account', image_file=image_file, form=form)

@app.route("/Report-Item-Register", methods=['GET', 'POST'])
@login_required
def report_item_register():
    student_number = current_user.student_no
    Course = current_user.Course
    Contact = current_user.Contact
    Fullname = current_user.Fullname
    form = ReportItemForm()
    
    if form.validate_on_submit():
        logging.debug("Form validated successfully!")
        try:
            image_dir = os.path.join(app.root_path, 'static/Images')
            os.makedirs(image_dir, exist_ok=True)

            img_data = None
            if form.image_item.data:
                image_file = form.image_item.data
              
                filename = f"{uuid.uuid4().hex}_{secure_filename(image_file.filename)}"
                img_path = os.path.join(image_dir, filename)
                image_file.save(img_path)
                img_filename = filename


            report_item = Report_item(
                Serial_No=generate_serial_number(),
                Student_No=current_user.student_no,
                Fullname=current_user.Fullname,
                Contact=current_user.Contact,
                Course=current_user.Course,
                Date_Lost=form.date_lost.data,
                Location_Lost=form.location_lost.data,
                Item_Name=form.item_name.data,
                Type_of_item=form.type_item.data,
                Color=form.color.data,
                Category=form.category.data,
                Description=form.description.data,
                img_item=img_filename 
            )
            logging.debug(report_item)
            db.session.add(report_item)
            db.session.commit()
            flash('Report item registered successfully!', 'success')
            return redirect(url_for('report_item_register'))
        except Exception as e:
            flash('An error occurred while registering the report item. Please try again later.', 'error')
            logging.error(f"Error registering report item: {e}")
            abort(500)
    else:
        logging.debug("Form validation failed!")
        logging.debug(form.errors)
    return render_template('REPORT-ITEM-USER.html', form=form, generate_serial_number=generate_serial_number, student_number=student_number, Course=Course, Fullname=Fullname, Contact=Contact)


@app.route("/retrieve-item/<int:item_id>", methods=["GET", "POST"])
def retrieve_item_user(item_id):
    student_number = current_user.student_no
    Course = current_user.Course
    Contact = current_user.Contact
    Fullname = current_user.Fullname
    email = current_user.email
    request_serial_no = request_serial()
    item = Register_item.query.get_or_404(item_id)
    image_folder_path = os.path.join(current_app.root_path, 'static', 'Images')  

    if request.method == "POST":
        id_img = request.files["id_img"]
        sign_img = request.files["sign_img"]
        
        if id_img and sign_img:
            id_img_filename = f"{uuid.uuid4()}_{secure_filename(id_img.filename)}"
            sign_img_filename = f"{uuid.uuid4()}_{secure_filename(sign_img.filename)}"

            id_img_path = os.path.join(image_folder_path, id_img_filename)
            sign_img_path = os.path.join(image_folder_path, sign_img_filename)

            id_img.save(id_img_path)
            sign_img.save(sign_img_path)

            new_request = RetrievalRequest(
                item_id=item_id,
                item_SN=item.Serial_No,
                Request_SN=request_serial_no,
                student_no=student_number,
                fullname=Fullname,
                course=Course,
                contact=Contact,
                email=email,
                id_img=id_img_filename,
                sign_img=sign_img_filename,
                status="Pending"
            )

            db.session.add(new_request)
            db.session.commit()

            flash("Request submitted successfully!", "success")
            return redirect(url_for("home", item_id=item_id))
        else:
            flash("Please upload both ID and signature images.", "danger")
    
    return render_template("RETRIEVE-ITEM-USER.html", 
                           item=item, 
                           student_number=student_number, 
                           Course=Course, 
                           Fullname=Fullname, 
                           Contact=Contact, 
                           request_serial=request_serial_no, 
                           email=email,
                           image_folder_path=image_folder_path)
def request_serial():
    prefix = "Request"  
    date_part = datetime.datetime.now().strftime("%Y%m%d%H%M%S")  
    random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))  
    return f"{prefix}-{date_part}-{random_part}"



@app.route("/Register-Your-item", methods=['GET', 'POST'])
@login_required
def register_item_form_user():
    student_number = current_user.student_no
    course = current_user.Course
    contact = current_user.Contact
    fullname = current_user.Fullname
    register = RegisterItemFormUser()

    if register.validate_on_submit():
        logging.debug("Form validated successfully!")
        try:
            image_dir = os.path.join(app.root_path, 'static/Images')
            os.makedirs(image_dir, exist_ok=True)

            img_filename = None
            if register.image_item.data:
                image_file = register.image_item.data
                filename = f"{uuid.uuid4().hex}_{secure_filename(image_file.filename)}"
                img_path = os.path.join(image_dir, filename)
                image_file.save(img_path)
                img_filename = filename
                
            register = Register_item(
                Serial_No=generate_serial_number(),
                Student_No=current_user.student_no,
                Fullname=current_user.Fullname,
                Contact=current_user.Contact,
                Course=current_user.Course,
                Item_Name=register.item_name.data,
                Type_Item=register.type_item.data,
                Color=register.color.data,
                Category=register.category.data,
                description=register.description.data,
                Status="Register",
                Image=img_filename,
                accno = current_user.Account_Id
            )
            print("all data   : " , register)
            db.session.add(register)
            db.session.commit()
            flash('Item registered successfully!', 'success')
            return redirect(url_for('register_item_form_user'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while registering the report item. Please try again later.', 'error')
            logging.error(f"Error registering report item: {e}")
            abort(500)
    else:
        logging.debug("Form validation failed!")
    return render_template('REGISTER-ITEM-USER.html', register=register, generate_serial_number=generate_serial_number, student_number=student_number, course=course, fullname=fullname, contact=contact)



@app.route('/Item-Status')
@login_required
def status():
    retrieve_items = RetrievalRequest.query.filter_by(
        student_no=current_user.student_no,
        fullname=current_user.Fullname,
        email=current_user.email
    ).all()

    item_ids = [item.item_id for item in retrieve_items]
    serial_numbers = [item.item_SN for item in retrieve_items]

    register_items = Register_item.query.filter(
        Register_item.Item_Id.in_(item_ids),
        Register_item.Serial_No.in_(serial_numbers)
    ).all()

    register_items_2 = Register_item.query.filter(
        Register_item.Fullname == current_user.Fullname,
        Register_item.Student_No == current_user.student_no,
        Register_item.accno == current_user.Account_Id
    ).all()

    register_dict = {register.Serial_No: register for register in register_items}

    return render_template(
        "STATUS-USER.html",
        retrieve_items=retrieve_items,
        register_dict=register_dict,
        register_items_2=register_items_2
    )
@app.route("/Modify-Your-Item/<string:serial_no>/<string:accno>/<int:item_id>", methods=['GET', 'POST'])
@login_required
def modify_item(serial_no, accno, item_id):
    item = Register_item.query.filter_by(Serial_No=serial_no, accno=accno, Item_Id=item_id).first()
    if request.method == 'POST':
        item.Date_Lost = datetime.datetime.strptime(request.form.get('datelost'), '%Y-%m-%d').date()
        item.Location_Lost = request.form.get('locationlost')
        item.description = request.form.get('description')
        item.Status = 'Lost' 

        try:
            db.session.commit()
            flash('Item has been modified successfully.', 'success')
            return redirect(url_for('status'))
        except Exception as e:
            print(e)
            flash('An error occurred while modifying the item.', 'danger')
            return redirect(url_for('status'))

    return render_template('Modify-item-user.html', item=item)

def admin_required(view_func):
    """Custom decorator to require admin login."""
    @wraps(view_func)
    def decorated_view(*args, **kwargs):
        admin_Email = "FinditAdmin@gmail.com"
        if not current_user.is_authenticated or current_user.email != admin_Email:
            abort(403)  
        return view_func(*args, **kwargs)
    return decorated_view


@app.route("/Register-items", methods=['GET', 'POST'])
@admin_required
def registeritem():
    form = RegisterItemFormss()
    try:
        if form.validate_on_submit():
            image_file = form.image_item.data
            if image_file:
                image_filename = f"{uuid.uuid4()}_{secure_filename(image_file.filename)}"
                image_dir = os.path.join(current_app.root_path, 'static', 'Images')
                os.makedirs(image_dir, exist_ok=True)  
                image_path = os.path.join(image_dir, image_filename)
                image_file.save(image_path)

                new_item = Register_item(
                    Serial_No=generate_serial_number(),
                    Fullname=form.Fullname.data,
                    Contact=form.Contact.data,
                    Course=form.Course.data,
                    Student_No=form.Studentno.data,
                    Date_Lost=form.date_lost.data,
                    Location_Lost=form.location_lost.data,
                    Category=form.category.data,
                    Item_Name=form.item_name.data,
                    Type_Item=form.type_item.data,
                    Color=form.color.data,
                    Date_of_Register=form.date_of_register.data,
                    Status=form.status.data,
                    Image=image_filename,
                    description=form.description.data
                )
                db.session.add(new_item)
                db.session.commit()

                flash('Item registered successfully', 'success')
                return redirect(url_for('registeritem'))

        return render_template('register_item.html', form=form)

    except Exception as e:
        print(e)
        abort(404)


def generate_serial_number():
    prefix = "SN"  
    date_part = datetime.datetime.now().strftime("%Y%m%d%H%M%S")  
    random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))  
    return f"{prefix}-{date_part}-{random_part}"


    

@app.route("/Dashboard")
@admin_required
def dashboard():
    try:
        lost_count = Register_item.query.filter_by(Status='Lost').count()
        found_count = Register_item.query.filter_by(Status='Found').count()
        all_count = Register_item.query.count()
        return render_template("dashboard.html", lost_count=lost_count, found_count=found_count, all_count=all_count)
    except Exception as e:
        abort(404)

@app.route("/report-items", methods=['GET', 'POST'])
@admin_required
def reportitem():
    page = request.args.get('page', 1, type=int)
    per_page = 5
    
    if request.method == 'POST':
        search_term = request.form['search']
        report_items = Report_item.query.filter((Report_item.Serial_No.like(f'%{search_term}%')) 
                                                    |(Report_item.Student_No.like(f'%{search_term}%')) 
                                                    |(Report_item.Fullname.like(f'%{search_term}%'))
                                                    |(Report_item.Item_Name.like(f'%{search_term}%'))
                                                    |(Report_item.Type_of_item.like(f'%{search_term}%')) 
                                                    |(Report_item.Color.like(f'%{search_term}%')) 
                                                    |(Report_item.Category.like(f'%{search_term}%'))
                                                    |(Report_item.Description.like(f'%{search_term}%'))
                                                    |(Report_item.Contact.like(f'%{search_term}%'))
                                                    |(Report_item.Course.like(f'%{search_term}%'))).paginate(page=page, per_page=per_page)
    else:
        report_items = Report_item.query.paginate(page=page, per_page=per_page)
    
    image_folder_path = os.path.join(app.root_path, 'static', 'Images')
    return render_template("Report_Item_Admin.html", report_items=report_items, image_folder=image_folder_path)


@app.route('/report-items/View-item/<string:serial_no>/<int:Item_Id>')
@admin_required
def reportitem_view(serial_no, Item_Id):
    time.sleep(0.5)
    report_item = Report_item.query.filter_by(Serial_No=serial_no,Item_Id=Item_Id).first()
    image_folder_path = os.path.join(app.root_path, 'static', 'Images')  
    if report_item:
        if report_item.img_item:
            try:
                with open(report_item.img_item, "rb") as img_file:
                    report_item.img_item = base64.b64encode(img_file.read()).decode('utf-8')
            except Exception as e:
                logging.error(f"Error encoding image for item {report_item.Item_Id}: {e}")
        return render_template('view-item-report.html', report_item=report_item,image_folder_path=image_folder_path)
    else:
        abort(404)

@app.route('/move-item/<int:item_id>', methods=['POST'])
def move_item(item_id):
    report_item = Report_item.query.get_or_404(item_id)
    new_item = Register_item(Serial_No=report_item.Serial_No,Student_No=report_item.Student_No,Fullname=report_item.Fullname,Contact=report_item.Contact,Course=report_item.Course,Date_Lost=report_item.Date_Lost,Location_Lost=report_item.Location_Lost,Category=report_item.Category, Item_Name=report_item.Item_Name,Type_Item=report_item.Type_of_item,Color=report_item.Color,Date_of_Register= report_item.Report_Date,Status='Lost',  Image=report_item.img_item,  description=report_item.Description)
    db.session.add(new_item)
    db.session.delete(report_item)
    db.session.commit()
    flash("Successfully moved item to Inventory", "success")
    return redirect(url_for('reportitem'))


@app.route("/Inventory", methods=['GET', 'POST'])
@admin_required
def Inventory():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = int(request.args.get('per_page', 5))

        if request.method == 'POST':
            search_term = request.form['search']
            registered_items = Register_item.query.filter(or_(
                Register_item.Student_No.like(f"%{search_term}%"),
                Register_item.Serial_No.like(f"%{search_term}%"),
                Register_item.Fullname.like(f"%{search_term}%"),
                Register_item.Contact.like(f"%{search_term}%"),
                Register_item.Course.like(f"%{search_term}%"),
                Register_item.Category.like(f"%{search_term}%"),
                Register_item.Item_Name.like(f"%{search_term}%"),
                Register_item.Type_Item.like(f"%{search_term}%"),
                Register_item.Color.like(f"%{search_term}%"),
                Register_item.Status.like(f"%{search_term}%")
            )).paginate(page=page, per_page=per_page)
        else:
            registered_items = Register_item.query.paginate(page=page, per_page=per_page)
        
        image_folder_path = os.path.join(app.root_path, 'static', 'Images')    

        return render_template("inventory.html", registered_items=registered_items,image_folder=image_folder_path)

    except Exception as e:
        logging.error(f"Error fetching inventory: {e}")
        return "An error occurred while processing your request."


@app.route("/Inventory/Retrieve-Item/<string:serial_no>/<int:Item_Id>", methods=['GET', 'POST'])
@admin_required
def retrieve_item(serial_no, Item_Id):
    item = Register_item.query.filter(Register_item.Serial_No == serial_no, Register_item.Item_Id == Item_Id).first()

    serial_number = Register_item.Serial_No
    item_id = Register_item.Item_Id
    requests = RetrievalRequest.query.filter(
        RetrievalRequest.item_SN == serial_number,
        RetrievalRequest.item_id == item_id
    ).all()
    image_folder_path = os.path.join(app.root_path, 'static', 'Images') 
    if item:
        if item.Image:
            try:
                with open(item.Image, "rb") as img_file:
                    item.Image = base64.b64encode(img_file.read()).decode('utf-8')
            except Exception as e:
                logging.error(f"Error encoding image for item {item.Item_Id}: {e}")
        if requests:
            for req in requests:
                if req.id_img:
                    try:
                        with open(req.id_img, "rb") as img_file:
                            req.id_img = base64.b64encode(img_file.read()).decode('utf-8')
                    except Exception as e:
                        logging.error(f"Error encoding image for request {req.request_id}: {e}")
                if req.sign_img:
                    try:
                        with open(req.sign_img, "rb") as img_file:
                            req.sign_img = base64.b64encode(img_file.read()).decode('utf-8')
                    except Exception as e:
                        logging.error(f"Error encoding image for request {req.request_id}: {e}")

        if request.method == 'POST':
            request_id = request.form.get('request_id')
            retrieval_request = RetrievalRequest.query.get(request_id)
            if retrieval_request:
                retrieval_request.status = 'Claim'
                item.Image = item.Image
                item.Status = 'Found'
                item.Date_of_Claim = datetime.datetime.now()
                db.session.commit()
                flash('Retrieval request approved successfully', 'success')
            else:
                flash('Retrieval request not found', 'error')
            return redirect(url_for('dashboard'))

        return render_template("Retrieve.html", item=item, requests=requests,image_folder_path =image_folder_path )
    else:
        abort(404)

@app.route("/Inventory/View-item/<string:serial_no>/<int:Item_Id>")
@admin_required
def view_item(serial_no, Item_Id):
    item = Register_item.query.filter(Register_item.Serial_No == serial_no, Register_item.Item_Id == Item_Id).first()
    
    image_folder_path = os.path.join(app.root_path, 'static', 'Images')     
    return render_template("view-item.html", item=item,image_folder_path=image_folder_path)
 